package juegorol;

public class Arquero extends Personaje {

    public Arquero(String nombre, int vida, int ataque) {
        super(nombre, vida, ataque);
    }

    public void disparo(Personaje enemigo) {

        if (!puedeAtacar()) {
            System.out.println(getNombre() + " no puede atacar.");
            return;
        }

        System.out.println(getNombre() + " dispara flecha!");
        enemigo.recibirDaño(getAtaque());
    }
}