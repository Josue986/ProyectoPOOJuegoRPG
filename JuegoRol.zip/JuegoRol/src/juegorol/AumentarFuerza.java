package juegorol;

public class AumentarFuerza implements IEstadoAlterado {

    private int turnos = 2;
    private boolean aplicado = false;

    @Override
    public void aplicar(Personaje p) {

        if (!aplicado) {
            p.setAtaque(p.getAtaque() + 10);
            aplicado = true;

            System.out.println(p.getNombre() + " aumenta ATAQUE +10");
        }

        turnos--;

        if (turnos <= 0) {
            p.setAtaque(p.getAtaque() - 10);
        }
    }

    @Override
    public boolean puedeAtacar() {
        return true;
    }

    @Override
    public boolean terminado() {
        return turnos <= 0;
    }

    @Override
    public String getNombre() {
        return "Aumentar Fuerza";
    }
}