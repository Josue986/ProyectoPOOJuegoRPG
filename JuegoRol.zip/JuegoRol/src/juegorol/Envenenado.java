package juegorol;

public class Envenenado implements IEstadoAlterado {

    private int turnos = 3;

    @Override
    public void aplicar(Personaje p) {

        p.setVida(p.getVida() - 5);
        System.out.println(p.getNombre() + " pierde 5 de vida por VENENO.");

        turnos--;
    }

    @Override
    public boolean puedeAtacar() {
        return true;
    }

    @Override
    public boolean terminado() {
        return turnos <= 0;
    }

    @Override
    public String getNombre() {
        return "Envenenado";
    }
}