package juegorol;

import java.util.ArrayList;

public abstract class Personaje {

    private String nombre;
    private int vida;
    private int ataque;

    private ArrayList<IEstadoAlterado> estados = new ArrayList<>();

    public Personaje(String nombre, int vida, int ataque) {
        this.nombre = nombre;
        this.vida = vida;
        this.ataque = ataque;
    }

    public String getNombre() {
        return nombre;
    }

    public int getVida() {
        return vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public void agregarEstado(IEstadoAlterado e) {
        estados.add(e);
        System.out.println(nombre + " recibe estado: " + e.getNombre());
    }

    public void aplicarEstados() {

        ArrayList<IEstadoAlterado> borrar = new ArrayList<>();

        for (IEstadoAlterado e : estados) {
            e.aplicar(this);

            if (e.terminado()) {
                borrar.add(e);
            }
        }

        estados.removeAll(borrar);
    }

    public boolean puedeAtacar() {

        for (IEstadoAlterado e : estados) {
            if (!e.puedeAtacar()) {
                return false;
            }
        }
        return true;
    }

    public void recibirDaño(int daño) {
        vida -= daño;
        System.out.println(nombre + " recibe " + daño + " daño. Vida: " + vida);
    }
}