package juegorol;

public class Guerrero extends Personaje {

    public Guerrero(String nombre, int vida, int ataque) {
        super(nombre, vida, ataque);
    }

    public void golpeFuerte(Personaje enemigo) {

        if (!puedeAtacar()) {
            System.out.println(getNombre() + " no puede atacar.");
            return;
        }

        System.out.println(getNombre() + " usa GOLPE FUERTE!");
        enemigo.recibirDaño(getAtaque() + 5);
    }
}