package juegorol;

public class Mago extends Personaje {

    public Mago(String nombre, int vida, int ataque) {
        super(nombre, vida, ataque);
    }

    public void hechizo(Personaje enemigo) {

        if (!puedeAtacar()) {
            System.out.println(getNombre() + " no puede atacar.");
            return;
        }

        System.out.println(getNombre() + " lanza HECHIZO!");
        enemigo.recibirDaño(getAtaque() + 10);
    }
}