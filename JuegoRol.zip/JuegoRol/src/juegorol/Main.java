package juegorol;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        ArrayList<Personaje> coliseo = new ArrayList<>();

        // PERSONAJES DISPONIBLES
        coliseo.add(new Guerrero("Thor", 120, 20));
        coliseo.add(new Mago("Merlín", 80, 15));
        coliseo.add(new Arquero("Robin", 90, 18));

        Personaje jugador1 = null;
        Personaje jugador2 = null;

        // ================= SELECCIÓN =================
        while (true) {

            System.out.println("\n===== COLISEO DE COMBATE =====");

            for (int i = 0; i < coliseo.size(); i++) {
                System.out.println((i + 1) + ". " +
                        coliseo.get(i).getNombre() +
                        " (" + coliseo.get(i).getClass().getSimpleName() + ")");
            }

            System.out.print("\nSelecciona Jugador 1 (1-3): ");
            int p1 = scanner.nextInt() - 1;

            System.out.print("Selecciona Jugador 2 (1-3): ");
            int p2 = scanner.nextInt() - 1;

            if (p1 == p2) {
                System.out.println("No puedes elegir el mismo personaje");
                continue;
            }

            if (p1 < 0 || p1 >= coliseo.size() || p2 < 0 || p2 >= coliseo.size()) {
                System.out.println("Selección inválida");
                continue;
            }

            jugador1 = coliseo.get(p1);
            jugador2 = coliseo.get(p2);
            break;
        }

        System.out.println("\n COMBATE INICIA: " +
                jugador1.getNombre() + " VS " + jugador2.getNombre());

        int turno = 1;

        // ================= COMBATE =================
        while (jugador1.getVida() > 0 && jugador2.getVida() > 0) {

            System.out.println("\n===== TURNO " + turno + " =====");

            System.out.println("\nTurno de " + jugador1.getNombre());
            mostrarAcciones(scanner, jugador1, jugador2);

            if (jugador2.getVida() <= 0) break;

            System.out.println("\nTurno de " + jugador2.getNombre());
            mostrarAcciones(scanner, jugador2, jugador1);

            System.out.println("\nVIDAS:");
            System.out.println(jugador1.getNombre() + ": " + jugador1.getVida());
            System.out.println(jugador2.getNombre() + ": " + jugador2.getVida());

            turno++;
        }

        // ================= GANADOR =================
        System.out.println("\n===== FIN DEL COMBATE =====");

        if (jugador1.getVida() > 0) {
            System.out.println("GANADOR: " + jugador1.getNombre());
        } else {
            System.out.println("GANADOR: " + jugador2.getNombre());
        }
    }

    // ================= MENÚ DE ACCIONES =================
    public static void mostrarAcciones(Scanner scanner, Personaje atacante, Personaje enemigo) {

        System.out.println("1. Ataque básico");
        System.out.println("2. Habilidad especial");
        System.out.println("3. Escudo (reduce daño)");

        int opcion = scanner.nextInt();

        switch (opcion) {

            case 1:
                if (atacante.puedeAtacar()) {
                    enemigo.recibirDaño(atacante.getAtaque());
                } else {
                    System.out.println("No puedes atacar");
                }
                break;

            case 2:

                if (atacante instanceof Guerrero) {
                    ((Guerrero) atacante).golpeFuerte(enemigo);
                }

                if (atacante instanceof Mago) {
                    ((Mago) atacante).hechizo(enemigo);
                }

                if (atacante instanceof Arquero) {
                    ((Arquero) atacante).disparo(enemigo);
                }
                break;

            case 3:
                System.out.println(atacante.getNombre() + " activa ESCUDO");
                atacante.setAtaque(atacante.getAtaque()); // placeholder simple
                break;
        }
    }
}