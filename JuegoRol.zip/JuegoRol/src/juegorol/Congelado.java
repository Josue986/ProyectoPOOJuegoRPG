package juegorol;

public class Congelado implements IEstadoAlterado {

    private int turnos = 1;

    @Override
    public void aplicar(Personaje p) {
        System.out.println(p.getNombre() + " está CONGELADO.");
        turnos--;
    }

    @Override
    public boolean puedeAtacar() {
        return false;
    }

    @Override
    public boolean terminado() {
        return turnos <= 0;
    }

    @Override
    public String getNombre() {
        return "Congelado";
    }
}