package juegorol;

public interface IEstadoAlterado {

    void aplicar(Personaje personaje);

    boolean puedeAtacar();

    boolean terminado();

    String getNombre();
}